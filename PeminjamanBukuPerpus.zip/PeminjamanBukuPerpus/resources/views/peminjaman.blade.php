<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi Peminjaman</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * { box-sizing: border-box; font-family: Poppins, sans-serif; }

        body { margin: 0; background: #f8fafc; font-size: 13px; }

        /* ===== NAVBAR ===== */
        .navbar {
            background: #7c2d12;
            color: white;
            padding: 12px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand { font-weight: 600; font-size: 20px; }

        .menu { display: flex; gap: 14px; }

        .menu a {
            color: white;
            text-decoration: none;
            font-size: 12px;
            padding: 6px 10px;
            border-radius: 6px;
        }

        .menu a:hover,
        .menu .active { background: rgba(255, 255, 255, .18); }

        /* ===== CONTENT ===== */
        .container { padding: 26px 34px; }

        /* ===== TOP BAR ===== */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        /* ===== BUTTON ===== */
        .btn {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 11px;
            font-weight: 500;
            text-decoration: none;
        }

        .btn-add { background: #fb923c; color: white; }

        /* ===== FORM ===== */
        .form-box {
            max-width: 420px;
            background: white;
            padding: 18px;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        select {
            width: 100%;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
            margin-bottom: 12px;
            font-size: 12px;
        }

        .checkbox-group {
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 10px;
            max-height: 170px;
            overflow: auto;
            margin-bottom: 14px;
            font-size: 12px;
            background: #f9fafb;
        }

        .checkbox-group label {
            display: block;
            margin-bottom: 6px;
        }

        .disabled {
            color: #9ca3af;
        }

        /* ===== GRID ===== */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 18px;
        }

        /* ===== CARD ===== */
        .card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 14px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,.06);
        }

        .member {
            font-weight: 600;
            font-size: 14px;
            color: #7c2d12;
        }

        .books {
            background: #f8fafc;
            border: 1px dashed #e5e7eb;
            border-radius: 8px;
            padding: 8px 10px;
            font-size: 12px;
            color: #374151;
            line-height: 1.5;
        }

        .dates {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            color: #64748b;
        }

        /* ===== STATUS ===== */
        .status {
            display: inline-block;
            font-size: 10px;
            padding: 4px 10px;
            border-radius: 20px;
            width: fit-content;
            font-weight: 600;
        }

        .status-ok { background: #dcfce7; color: #166534; }
        .status-overdue { background: #fee2e2; color: #991b1b; }

        .page-title{
            font-size:18px;
            font-weight:600;
        }
    </style>
</head>

<body>

<!-- ===== NAVBAR ===== -->
<div class="navbar">
    <div class="brand">Perpustakaan</div>

    <div class="menu">
        <a href="/buku"><i class="fa-solid fa-book"></i> Buku</a>
        <a href="/member"><i class="fa-solid fa-users"></i> Member</a>
        <a href="/peminjaman" class="active"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
        <a href="/"><i class="fa-solid fa-arrow-left"></i> Logout</a>
    </div>
</div>

<div class="container">

{{-- ================= CREATE ================= --}}
@if($mode == 'create')

<div class="form-box">
    <b>Tambah Peminjaman</b><br><br>

    <form action="/peminjaman" method="POST">
        @csrf

        <label>Member</label>
        <select name="member_id" required>
            @foreach($member as $m)
                <option value="{{ $m->id }}">{{ $m->nama }}</option>
            @endforeach
        </select>

        <label>Pilih Buku</label>
        <div class="checkbox-group">
            @foreach($buku as $b)
                <label class="{{ $b->stok == 0 ? 'disabled' : '' }}">
                    <input type="checkbox" name="buku_id[]" value="{{ $b->id }}"
                        {{ $b->stok == 0 ? 'disabled' : '' }}>
                    {{ $b->judul }} (stok: {{ $b->stok }})
                    @if($b->stok == 0)
                        <span style="color:red;font-size:11px;"> - habis</span>
                    @endif
                </label>
            @endforeach
        </div>

        <button class="btn btn-add">Simpan</button>
        <a href="/peminjaman" class="btn">Batal</a>
    </form>
</div>

@endif

{{-- ================= LIST ================= --}}
@if($mode == 'list')

<div class="topbar">
    <div class="page-title">Data Peminjaman</div>
    <a href="/peminjaman/create" class="btn btn-add">
        <i class="fa-solid fa-plus"></i> Tambah
    </a>
</div>

<div class="grid">

@foreach($peminjaman as $p)

@php
    $today = \Carbon\Carbon::today();
    $kembali = \Carbon\Carbon::parse($p->tanggal_kembali);
@endphp

<div class="card">

    <div class="member">{{ $p->member->nama }}</div>

    <div class="books">
        @foreach($p->detail as $d)
            • {{ $d->buku->judul }}<br>
        @endforeach
    </div>

    <div class="dates">
        <div>Pinjam: {{ $p->tanggal_pinjam }}</div>
        <div>Kembali: {{ $p->tanggal_kembali }}</div>
    </div>

    @if($today->gt($kembali))
        <div class="status status-overdue">Overdue</div>
    @else
        <div class="status status-ok">Sedang Dipinjam</div>
    @endif

</div>

@endforeach

</div>
@endif

</div>

</body>
</html>
