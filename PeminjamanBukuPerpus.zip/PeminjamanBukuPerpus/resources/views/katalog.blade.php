<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Katalog Buku</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{box-sizing:border-box;font-family:Poppins,sans-serif}
body{margin:0;background:#f4f6f8;font-size:13px;color:#111827}

/* ===== NAVBAR ===== */
.navbar{
    background:#7c2d12;color:white;padding:12px 30px;
    display:flex;justify-content:space-between;align-items:center;
}
.brand{font-weight:600;font-size:20px}
.back{
    color:white;text-decoration:none;font-size:12px;
    padding:6px 10px;border-radius:6px;
}
.back:hover{background:rgba(255,255,255,.18)}

/* ===== CONTENT ===== */
.container{padding:26px 34px}

/* ===== TOP BAR ===== */
.topbar{
    display:flex;justify-content:space-between;
    align-items:center;margin-bottom:18px;
}

/* ===== SEARCH ===== */
.search-box input{
    padding:6px 10px;border-radius:6px;
    border:1px solid #e5e7eb;font-size:12px;
}

/* ===== GRID ===== */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    gap:35px;
}

/* ===== BOOK CARD ===== */
.book{
    background:white;border-radius:14px;overflow:hidden;
    box-shadow:0 6px 18px rgba(0,0,0,.08);
    transition:.25s;position:relative;
}
.book:hover{transform:translateY(-6px)}

.cover{
    height:180px;
    background:linear-gradient(135deg,#fde68a,#fb923c);
    display:flex;align-items:center;justify-content:center;
    font-size:60px;color:white;
}

.book-body{padding:12px}
.book-title{font-weight:600;font-size:13px;margin-bottom:4px}
.book-author{font-size:11px;color:#6b7280}

.stock{
    margin-top:6px;font-size:10px;
    padding:3px 8px;border-radius:20px;width:fit-content;
}
.ok{background:#dcfce7;color:#166534}
.empty{background:#fee2e2;color:#991b1b}

.page-title{
    font-size:18px;
    font-weight:600;
}
</style>
</head>

<body>

<!-- ===== NAVBAR ===== -->
<div class="navbar">
    <div class="brand">Katalog Perpustakaan</div>
    <a href="/" class="back"><i class="fa-solid fa-arrow-left"></i> Logout</a>
</div>

<div class="container">

<div class="topbar">
    <div class="page-title">Daftar Buku</div>

    <form method="GET" id="searchForm" class="search-box">
        <input id="searchInput" name="search" placeholder="Cari buku..."
               value="{{ request('search') }}">
    </form>
</div>

<div class="grid">

@forelse($buku as $b)
<div class="book">

    <div class="cover">
        <i class="fa-solid fa-book"></i>
    </div>

    <div class="book-body">
        <div class="book-title">{{ $b->judul }}</div>
        <div class="book-author">{{ $b->penulis }}</div>

        @if($b->stok > 0)
            <div class="stock ok">Stok: {{ $b->stok }}</div>
        @else
            <div class="stock empty">Habis</div>
        @endif
    </div>

</div>
@empty
<p style="color:#6b7280">Buku tidak ditemukan.</p>
@endforelse

</div>
</div>

<script>
let timer;
document.getElementById('searchInput').addEventListener('keyup', function () {
    clearTimeout(timer);
    timer = setTimeout(() => {
        document.getElementById('searchForm').submit();
    }, 400);
});
</script>

</body>
</html>
