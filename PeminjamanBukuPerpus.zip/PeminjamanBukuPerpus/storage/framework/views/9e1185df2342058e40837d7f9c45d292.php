<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
*{font-family:Poppins,sans-serif;box-sizing:border-box}

body{
    margin:0;min-height:100vh;
    background:#f7f3ef;
    display:flex;align-items:center;justify-content:center;
}

.box{
    background:#fffaf5;
    padding:32px;
    width:100%;max-width:380px;
    border-radius:16px;
    border:1px solid #fed7aa;
}

h2{margin-top:0;color:#7c2d12}

label{font-size:12px;display:block;margin-top:12px}
input{
    width:100%;padding:10px;
    border-radius:8px;border:1px solid #fed7aa;
}

button{
    margin-top:18px;width:100%;
    padding:10px;border:none;border-radius:8px;
    background:#fb923c;color:white;
    cursor:pointer;
}
</style>
</head>

<body>

<div class="box">
    <h2>Login</h2>

    <?php if(session('error')): ?>
        <p style="color:red;font-size:12px"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <form method="POST" action="/login">
        <?php echo csrf_field(); ?>

        <label>Username</label>
        <input name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button>Login</button>
    </form>
</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/login.blade.php ENDPATH**/ ?>