<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Perpustakaan</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{box-sizing:border-box;font-family:'Poppins',sans-serif}

body{
    margin:0;
    background:#eef2f7;
}

/* ===== LAYOUT ===== */
.app{
    display:flex;
    min-height:100vh;
}

/* ===== SIDEBAR ===== */
.sidebar{
    width:240px;
    background:linear-gradient(180deg,#0f172a,#020617); /* NAVY */
    color:white;
    padding:26px 18px;
    position:fixed;
    top:0;bottom:0;left:0;
}

.brand{
    font-size:18px;
    font-weight:600;
    text-align:center;
    margin-bottom:35px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:12px 14px;
    margin-bottom:10px;
    color:white;
    text-decoration:none;
    border-radius:10px;
    transition:.2s;
    font-size:14px;
}

.menu a:hover{
    background:rgba(255,255,255,.12);
}

/* ===== MAIN ===== */
.main{
    margin-left:240px;
    flex:1;
    display:flex;
    flex-direction:column;
}

/* ===== HEADER ===== */
.header{
    background:white;
    padding:18px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 4px 14px rgba(0,0,0,.08);
}

.header h3{
    margin:0;
    font-size:18px;
    color:#020617;
}

/* ===== CONTENT ===== */
.content{
    padding:35px;
}

/* ===== WELCOME ===== */
.welcome{
    margin-bottom:30px;
}

.welcome h2{
    margin:0;
    font-size:22px;
    color:#020617;
}

.welcome p{
    margin-top:6px;
    color:#64748b;
}

/* ===== MENU GRID ===== */
.menu-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:26px;
}

/* ===== CARD ===== */
.card{
    background:white;
    padding:26px;
    border-radius:18px;
    text-decoration:none;
    color:#020617;
    display:flex;
    align-items:center;
    gap:16px;
    box-shadow:0 8px 24px rgba(0,0,0,.08);
    border:1px solid #e5e7eb;
    transition:.25s;
}

.card:hover{
    transform:translateY(-6px);
    box-shadow:0 14px 40px rgba(15,23,42,.25);
    border-color:#cbd5f5;
}

/* ===== ICON ===== */
.icon-wrap{
    width:54px;
    height:54px;
    border-radius:14px;
    background:#e0e7ff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
    color:#0f172a;
}

.title{font-weight:600}
.desc{font-size:13px;color:#64748b;margin-top:4px}
</style>
</head>

<body>

<div class="app">

    <!-- ===== SIDEBAR ===== -->
    <div class="sidebar">
        <div class="brand">📚 Perpustakaan</div>

        <div class="menu">
            <a href="/dashboard"><i class="fa-solid fa-gauge"></i> Dashboard</a>
            <a href="/buku"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="/member"><i class="fa-solid fa-users"></i> Member</a>
            <a href="/peminjaman"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
            <a href="/"><i class="fa-solid fa-arrow-left"></i> Keluar</a>
        </div>
    </div>

    <!-- ===== MAIN ===== -->
    <div class="main">

        <!-- HEADER -->
        <div class="header">
            <h3>Dashboard Petugas</h3>
        </div>

        <!-- CONTENT -->
        <div class="content">

            <div class="welcome">
                <h2>Selamat Datang, Petugas</h2>
                <p>Silakan pilih menu untuk mengelola data dan transaksi perpustakaan.</p>
            </div>

            <div class="menu-grid">

                <a href="/buku" class="card">
                    <div class="icon-wrap"><i class="fa-solid fa-book"></i></div>
                    <div>
                        <div class="title">Data Buku</div>
                        <div class="desc">Kelola informasi buku</div>
                    </div>
                </a>

                <a href="/member" class="card">
                    <div class="icon-wrap"><i class="fa-solid fa-users"></i></div>
                    <div>
                        <div class="title">Data Member</div>
                        <div class="desc">Kelola data anggota</div>
                    </div>
                </a>

                <a href="/peminjaman" class="card">
                    <div class="icon-wrap"><i class="fa-solid fa-clipboard-list"></i></div>
                    <div>
                        <div class="title">Peminjaman</div>
                        <div class="desc">Transaksi peminjaman buku</div>
                    </div>
                </a>

            </div>

        </div>
    </div>

</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/dashboard.blade.php ENDPATH**/ ?>