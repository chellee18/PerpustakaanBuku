<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Buku</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
            font-family: Poppins, sans-serif;
        }

        body {
            margin: 0;
            background: #f4f6f8;
            font-size: 13px;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background: #7c2d12;
            color: white;
            padding: 12px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            font-weight: 600;
            font-size: 14px;
        }

        .menu {
            display: flex;
            gap: 14px;
            align-items: center;
        }

        .menu a {
            color: white;
            text-decoration: none;
            font-size: 12px;
            padding: 6px 10px;
            border-radius: 6px;
        }

        .menu a:hover,
        .menu .active {
            background: rgba(255, 255, 255, .18);
        }

        /* ===== CONTENT ===== */
        .container {
            padding: 26px 34px;
        }

        /* ===== TOP BAR ===== */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }

        .page-title {
            font-size: 16px;
            font-weight: 600;
        }

        /* ===== BUTTON ===== */
        .btn {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 11px;
            font-weight: 500;
            text-decoration: none;
        }

        .btn-add {
            background: #fb923c;
            color: white;
        }

        /* ===== FORM ===== */
        .form-box {
            max-width: 420px;
            background: white;
            padding: 18px;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
            margin-bottom: 12px;
            font-size: 12px;
        }

        /* ===== GRID ===== */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 35px;
        }

        /* ===== BOOK CARD ===== */
        .book {
            background: white;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 6px 18px rgba(0, 0, 0, .08);
            transition: .25s;
            position: relative;
        }

        .book:hover {
            transform: translateY(-6px);
        }

        .cover {
            height: 180px;
            background: linear-gradient(135deg, #fde68a, #fb923c);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
            color: white;
        }

        .book-body {
            padding: 12px;
        }

        .book-title {
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 4px;
        }

        .book-author {
            font-size: 11px;
            color: #6b7280;
        }

        .stock {
            margin-top: 6px;
            font-size: 10px;
            background: #ffedd5;
            color: #9a3412;
            padding: 3px 8px;
            border-radius: 20px;
            width: fit-content;
        }

        /* ===== HOVER ACTION ===== */
        .book-actions {
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, .45);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 14px;
            opacity: 0;
            transition: .25s;
        }

        .book:hover .book-actions {
            opacity: 1;
        }

        /* ===== ICON BUTTON ===== */
        .icon-btn {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            color: white;
        }

        .icon-edit { background: #2563eb; }
        .icon-del { background: #dc2626; }

        .icon-btn:hover {
            transform: scale(1.1);
        }

        /* ===== MODAL DELETE ===== */
        .modal-bg{
            position:fixed;
            inset:0;
            background:rgba(0,0,0,.45);
            display:none;
            align-items:center;
            justify-content:center;
            z-index:999;
        }

        .modal{
            background:white;
            padding:22px;
            border-radius:14px;
            width:100%;
            max-width:360px;
            text-align:center;
            border:1px solid #e5e7eb;
        }

        .modal h3{margin:0 0 8px;color:#991b1b}
        .modal p{font-size:12px;color:#374151}

        .modal-actions{
            margin-top:16px;
            display:flex;
            justify-content:center;
            gap:10px
        }

        .btn-cancel{background:#e5e7eb}
        .btn-delete{background:#dc2626;color:white}
    </style>
</head>

<body>

<!-- ===== NAVBAR ===== -->
<div class="navbar">
    <div class="brand">Perpustakaan</div>

    <div class="menu">
        <a href="/buku" class="active"><i class="fa-solid fa-book"></i> Buku</a>
        <a href="/member"><i class="fa-solid fa-users"></i> Member</a>
        <a href="/peminjaman"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
        <a href="/logout"><i class="fa-solid fa-arrow-left"></i> Logout</a>
    </div>
</div>

<div class="container">


<?php if($mode == 'create' || $mode == 'edit'): ?>

<div class="form-box">
    <b><?php echo e($mode == 'create' ? 'Tambah Buku' : 'Edit Buku'); ?></b><br><br>

    <form action="<?php echo e($mode == 'create' ? '/buku' : '/buku/'.$editBuku->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($mode == 'edit'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <input name="judul" placeholder="Judul Buku"
               value="<?php echo e($mode=='edit' ? $editBuku->judul : ''); ?>" required>

        <input name="penulis" placeholder="Penulis"
               value="<?php echo e($mode=='edit' ? $editBuku->penulis : ''); ?>" required>

        <input type="number" name="stok" placeholder="Stok"
               value="<?php echo e($mode=='edit' ? $editBuku->stok : ''); ?>" required>

        <button class="btn btn-add">Simpan</button>
        <a href="/buku" class="btn">Batal</a>
    </form>
</div>

<?php endif; ?>



<?php if($mode == 'list'): ?>

<div class="topbar">
    <div class="page-title">Katalog Buku</div>
    <a href="/buku/create" class="btn btn-add">
        <i class="fa-solid fa-plus"></i> Tambah
    </a>
</div>

<div class="grid">

<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="book">

    <div class="cover">
        <i class="fa-solid fa-book"></i>
    </div>

    <div class="book-body">
        <div class="book-title"><?php echo e($b->judul); ?></div>
        <div class="book-author"><?php echo e($b->penulis); ?></div>
        <div class="stock">Stok: <?php echo e($b->status_stok); ?></div>
    </div>

    <!-- HOVER ICON ACTION -->
    <div class="book-actions">

        <!-- EDIT -->
        <a href="/buku/<?php echo e($b->id); ?>/edit" class="icon-btn icon-edit">
            <i class="fa-solid fa-pen"></i>
        </a>

        <!-- DELETE (OPEN MODAL) -->
        <button type="button" class="icon-btn icon-del" onclick="openDelete(<?php echo e($b->id); ?>)">
            <i class="fa-solid fa-trash"></i>
        </button>

    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php endif; ?>

</div>

<!-- ===== MODAL DELETE ===== -->
<div class="modal-bg" id="deleteModal">
    <div class="modal">
        <h3>Hapus Buku?</h3>
        <p>Data buku akan dihapus permanen.</p>

        <form id="deleteForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <div class="modal-actions">
                <button type="button" class="btn btn-cancel" onclick="closeDelete()">Batal</button>
                <button class="btn btn-delete">Hapus</button>
            </div>
        </form>
    </div>
</div>

<script>
function openDelete(id){
    document.getElementById('deleteForm').action = '/buku/' + id;
    document.getElementById('deleteModal').style.display = 'flex';
}
function closeDelete(){
    document.getElementById('deleteModal').style.display = 'none';
}
</script>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/buku.blade.php ENDPATH**/ ?>