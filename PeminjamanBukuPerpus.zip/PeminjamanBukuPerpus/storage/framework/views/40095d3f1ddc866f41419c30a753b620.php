<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Buku</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{box-sizing:border-box;font-family:Poppins,sans-serif}
body{margin:0;background:#f4f6f8;font-size:13px}

/* ===== NAVBAR ===== */
.navbar{
    background:#7c2d12;color:white;padding:12px 30px;
    display:flex;justify-content:space-between;align-items:center;
}
.brand{font-weight:600;font-size:14px}
.menu{display:flex;gap:14px;align-items:center}
.menu a{
    color:white;text-decoration:none;font-size:12px;
    padding:6px 10px;border-radius:6px;
}
.menu a:hover,.menu .active{background:rgba(255,255,255,.18)}

/* ===== CONTENT ===== */
.container{padding:26px 34px}

/* ===== TOP BAR ===== */
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
.page-title{font-size:16px;font-weight:600}

/* ===== BUTTON ===== */
.btn{
    padding:6px 12px;border-radius:6px;border:none;
    cursor:pointer;font-size:11px;font-weight:500;
    text-decoration:none;
}
.btn-add{background:#fb923c;color:white}

/* ===== FORM ===== */
.form-box{
    max-width:420px;background:white;padding:18px;
    border:1px solid #e5e7eb;border-radius:10px;
}
input{
    width:100%;padding:8px;border-radius:6px;
    border:1px solid #e5e7eb;margin-bottom:12px;font-size:12px;
}

/* ===== GRID ===== */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    gap:35px;
}

/* ===== BOOK CARD ===== */
.book{
    background:white;border-radius:14px;overflow:hidden;
    box-shadow:0 6px 18px rgba(0,0,0,.08);
    transition:.25s;position:relative;
}
.book:hover{transform:translateY(-6px)}
.cover{
    height:180px;
    background:linear-gradient(135deg,#fde68a,#fb923c);
    display:flex;align-items:center;justify-content:center;
    font-size:60px;color:white;
}
.book-body{padding:12px}
.book-title{font-weight:600;font-size:13px;margin-bottom:4px}
.book-author{font-size:11px;color:#6b7280}
.stock{
    margin-top:6px;font-size:10px;background:#ffedd5;color:#9a3412;
    padding:3px 8px;border-radius:20px;width:fit-content;
}
</style>
</head>

<body>

<!-- ===== NAVBAR ===== -->
<div class="navbar">
    <div class="brand">Perpustakaan</div>

    <div class="menu">
        <a href="/buku" class="active"><i class="fa-solid fa-book"></i> Buku</a>
        <a href="/member"><i class="fa-solid fa-users"></i> Member</a>
        <a href="/peminjaman"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
        <a href="/"><i class="fa-solid fa-arrow-left"></i> Logout</a>
    </div>
</div>

<div class="container">


<?php if($mode == 'create'): ?>

<div class="form-box">
<b>Tambah Buku</b><br><br>

<form action="/buku" method="POST">
<?php echo csrf_field(); ?>

<input name="judul" placeholder="Judul Buku" required>
<input name="penulis" placeholder="Penulis" required>
<input type="number" name="stok" placeholder="Stok" required>

<button class="btn btn-add">Simpan</button>
<a href="/buku" class="btn">Batal</a>
</form>

</div>

<?php endif; ?>



<?php if($mode == 'list'): ?>

<div class="topbar">
    <div class="page-title">Katalog Buku</div>
    <a href="/buku/create" class="btn btn-add">
        <i class="fa-solid fa-plus"></i> Tambah
    </a>
</div>

<div class="grid">

<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="book">

    <div class="cover"><i class="fa-solid fa-book"></i></div>

    <div class="book-body">
        <div class="book-title"><?php echo e($b->judul); ?></div>
        <div class="book-author"><?php echo e($b->penulis); ?></div>
        <div class="stock">Stok: <?php echo e($b->status_stok); ?></div>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php endif; ?>

</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/buku.blade.php ENDPATH**/ ?>