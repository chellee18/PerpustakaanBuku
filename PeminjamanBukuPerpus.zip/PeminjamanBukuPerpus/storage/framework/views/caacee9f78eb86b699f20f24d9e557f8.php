<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pilih Akses</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{font-family:Poppins,sans-serif;box-sizing:border-box}

body{
    margin:0;
    min-height:100vh;
    background:#f7f3ef;
    display:flex;
}

/* ===== LEFT BANNER ===== */
.left{
    flex:1;
    background:linear-gradient(135deg,#7c2d12,#9a3412);
    color:white;
    padding:70px 60px;
    display:flex;
    flex-direction:column;
    justify-content:center;
}

.left h1{font-size:36px;margin:0 0 16px}
.left p{color:#fde68a;max-width:420px;line-height:1.6}

/* ===== RIGHT PANEL ===== */
.right{
    flex:1;
    background:#fffaf5;
    display:flex;
    justify-content:center;
    align-items:center;
}

.panel{width:100%;max-width:420px}

.panel h2{margin-top:0;font-size:24px;color:#7c2d12}
.panel p{color:#9a3412;margin-bottom:30px}

/* ===== ROLE BUTTON ===== */
.role{
    display:flex;
    align-items:center;
    gap:16px;
    padding:18px 20px;
    border-radius:14px;
    border:1px solid #fed7aa;
    text-decoration:none;
    color:#7c2d12;
    margin-bottom:18px;
    transition:.25s;
    background:#fff7ed;
    cursor:pointer;
}

.role:hover{
    border-color:#fb923c;
    box-shadow:0 10px 30px rgba(251,146,60,.25);
    transform:translateY(-4px);
    background:#ffedd5;
}

.icon{
    width:46px;height:46px;border-radius:12px;
    background:#fb923c;color:white;
    display:flex;align-items:center;justify-content:center;
    font-size:20px;
    box-shadow:0 6px 16px rgba(251,146,60,.45);
}

.role b{display:block}
.role small{color:#9a3412;font-size:13px}

/* ===== MODAL ===== */
.modal-bg{
    position:fixed;inset:0;
    background:rgba(0,0,0,.4);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:999;
}

.modal{
    background:#fffaf5;
    padding:26px;
    border-radius:16px;
    width:100%;
    max-width:380px;
    border:1px solid #fed7aa;
}

.modal h3{margin-top:0;color:#7c2d12}
.modal p{color:#9a3412;font-size:13px}

.modal label{
    font-size:12px;
    font-weight:500;
    display:block;
    margin-top:10px;
}

.modal input{
    width:100%;
    padding:9px;
    border-radius:8px;
    border:1px solid #fed7aa;
    margin-top:4px;
}

.modal-actions{
    margin-top:18px;
    display:flex;
    justify-content:flex-end;
    gap:10px;
}

.modal-actions button{
    padding:8px 14px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    font-size:12px;
}

.btn-login{background:#fb923c;color:white}

/* ===== WARNING ===== */
.login-error{
    background:#fee2e2;
    color:#991b1b;
    padding:8px 10px;
    border-radius:8px;
    font-size:12px;
    margin-bottom:10px;
}
</style>
</head>

<body>

<!-- LEFT -->
<div class="left">
    <h1>Sistem<br>Perpustakaan</h1>
    <p>
        Kelola data buku, member, dan transaksi peminjaman
        dalam satu sistem yang mudah digunakan.
    </p>
</div>

<!-- RIGHT -->
<div class="right">
    <div class="panel">
        <h2>Pilih Akses</h2>
        <p>Silakan pilih peran untuk melanjutkan ke sistem</p>

        <!-- PETUGAS -->
        <div class="role" onclick="openLogin()">
            <div class="icon"><i class="fa-solid fa-user-tie"></i></div>
            <div>
                <b>Petugas</b>
                <small>Kelola data dan transaksi</small>
            </div>
        </div>

        <!-- ANGGOTA -->
        <a href="/katalog" class="role">
            <div class="icon"><i class="fa-solid fa-book-open-reader"></i></div>
            <div>
                <b>Anggota</b>
                <small>Lihat katalog buku</small>
            </div>
        </a>
    </div>
</div>

<!-- ===== MODAL LOGIN PETUGAS ===== -->
<div class="modal-bg" id="loginModal">
    <div class="modal">
        <h3>Login Petugas</h3>
        <p>Masukkan username dan password</p>

        
        <?php if(session('error')): ?>
            <div class="login-error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label>Username</label>
            <input name="username" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <div class="modal-actions">
                <button type="button" onclick="closeLogin()">Batal</button>
                <button class="btn-login">Masuk</button>
            </div>
        </form>
    </div>
</div>

<script>
function openLogin(){
    document.getElementById('loginModal').style.display='flex';
}
function closeLogin(){
    document.getElementById('loginModal').style.display='none';
}
</script>


<?php if(session('error')): ?>
<script>
    document.getElementById('loginModal').style.display='flex';
</script>
<?php endif; ?>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/welcome_role.blade.php ENDPATH**/ ?>