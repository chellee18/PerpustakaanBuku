<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Member</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{box-sizing:border-box;font-family:Poppins,sans-serif}
body{margin:0;background:#f8fafc;font-size:13px}

/* ===== NAVBAR ===== */
.navbar{
    background:#7c2d12;color:white;padding:12px 30px;
    display:flex;justify-content:space-between;align-items:center;
}
.brand{font-weight:600;font-size:20px}
.menu{display:flex;gap:14px}
.menu a{
    color:white;text-decoration:none;font-size:12px;
    padding:6px 10px;border-radius:6px;
}
.menu a:hover,.menu .active{background:rgba(255,255,255,.18)}

/* ===== CONTENT ===== */
.container{padding:26px 34px}

/* ===== TOP BAR ===== */
.topbar{
    display:flex;justify-content:space-between;
    align-items:center;margin-bottom:16px;
}

/* ===== BUTTON ===== */
.btn{
    padding:6px 12px;border-radius:6px;border:none;
    cursor:pointer;font-size:11px;font-weight:500;
    text-decoration:none;
}
.btn-add{background:#fb923c;color:white}

/* ===== FORM ===== */
.form-box{
    max-width:420px;background:white;padding:18px;
    border:1px solid #e5e7eb;border-radius:10px;
}

input{
    width:100%;padding:8px;border-radius:6px;
    border:1px solid #e5e7eb;margin-bottom:12px;font-size:12px;
}

/* ===== TABLE ===== */
.table-box{
    background:white;
    border-radius:14px;
    box-shadow:0 6px 18px rgba(0,0,0,.08);
    overflow:hidden;
}

table{
    width:100%;
    border-collapse:collapse;
}

thead{background:#fff7ed}

th,td{
    padding:12px 14px;
    font-size:12px;
    text-align:left;
}

th{font-weight:600;color:#9a3412}
tbody tr:hover{background:#f9fafb}

.page-title{
    font-size:18px;
    font-weight:600;
}

/* ===== ICON ACTION ===== */
.action{
    display:flex;
    gap:10px;
}

.icon-btn{
    border:none;
    background:none;
    cursor:pointer;
    font-size:14px;
}

.icon-edit{color:#2563eb}
.icon-del{color:#dc2626}

/* ===== MODAL DELETE ===== */
.modal-bg{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:999;
}

.modal{
    background:white;
    padding:22px;
    border-radius:14px;
    width:100%;
    max-width:360px;
    text-align:center;
    border:1px solid #e5e7eb;
}

.modal h3{margin:0 0 8px;color:#991b1b}
.modal p{font-size:12px;color:#374151}

.modal-actions{
    margin-top:16px;
    display:flex;
    justify-content:center;
    gap:10px
}

.btn-cancel{background:#e5e7eb}
.btn-delete{background:#dc2626;color:white}
</style>
</head>

<body>

<!-- ===== NAVBAR ===== -->
<div class="navbar">
    <div class="brand">Perpustakaan</div>

    <div class="menu">
        <a href="/buku"><i class="fa-solid fa-book"></i> Buku</a>
        <a href="/member" class="active"><i class="fa-solid fa-users"></i> Member</a>
        <a href="/peminjaman"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
        <a href="/logout"><i class="fa-solid fa-arrow-left"></i> Logout</a>
    </div>
</div>

<div class="container">


<?php if($mode == 'create' || $mode == 'edit'): ?>

<div class="form-box">
<b><?php echo e($mode=='create'?'Tambah Member':'Edit Member'); ?></b><br><br>

<form action="<?php echo e($mode=='create'?'/member':'/member/'.$editMember->id); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php if($mode=='edit'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

<input name="nama" placeholder="Nama" value="<?php echo e($mode=='edit'?$editMember->nama:''); ?>" required>
<input name="alamat" placeholder="Alamat" value="<?php echo e($mode=='edit'?$editMember->alamat:''); ?>" required>
<input name="no_hp" placeholder="No HP" value="<?php echo e($mode=='edit'?$editMember->no_hp:''); ?>" required>

<button class="btn btn-add">Simpan</button>
<a href="/member" class="btn">Batal</a>
</form>
</div>

<?php endif; ?>


<?php if($mode == 'list'): ?>

<div class="topbar">
    <div class="page-title">Data Member</div>
    <a href="/member/create" class="btn btn-add">
        <i class="fa-solid fa-plus"></i> Tambah
    </a>
</div>

<div class="table-box">
<table>
<thead>
<tr>
    <th>Nama</th>
    <th>Alamat</th>
    <th>No HP</th>
    <th>Aksi</th>
</tr>
</thead>

<tbody>
<?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($m->nama); ?></td>
    <td><?php echo e($m->alamat); ?></td>
    <td><?php echo e($m->no_hp); ?></td>
    <td>
        <div class="action">

            <!-- EDIT -->
            <a href="/member/<?php echo e($m->id); ?>/edit" class="icon-btn icon-edit">
                <i class="fa-solid fa-pen"></i>
            </a>

            <!-- DELETE (OPEN MODAL) -->
            <button type="button" class="icon-btn icon-del"
                    onclick="openDelete(<?php echo e($m->id); ?>)">
                <i class="fa-solid fa-trash"></i>
            </button>

        </div>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>
</div>

<?php endif; ?>

</div>

<!-- ===== MODAL DELETE ===== -->
<div class="modal-bg" id="deleteModal">
    <div class="modal">
        <h3>Hapus Member?</h3>
        <p>Data member akan dihapus permanen.</p>

        <form id="deleteForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <div class="modal-actions">
                <button type="button" class="btn btn-cancel" onclick="closeDelete()">Batal</button>
                <button class="btn btn-delete">Hapus</button>
            </div>
        </form>
    </div>
</div>

<script>
function openDelete(id){
    document.getElementById('deleteForm').action = '/member/' + id;
    document.getElementById('deleteModal').style.display = 'flex';
}
function closeDelete(){
    document.getElementById('deleteModal').style.display = 'none';
}
</script>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/member.blade.php ENDPATH**/ ?>