<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi Peminjaman</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * { box-sizing: border-box; font-family: Poppins, sans-serif; }
        body { margin: 0; background: #f8fafc; font-size: 13px; }

        .navbar {
            background: #7c2d12;
            color: white;
            padding: 12px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .brand { font-weight: 600; font-size: 20px; }
        .menu { display: flex; gap: 14px; }
        .menu a {
            color: white; text-decoration: none; font-size: 12px;
            padding: 6px 10px; border-radius: 6px;
        }
        .menu a:hover,.menu .active { background: rgba(255, 255, 255, .18); }

        .container { padding: 26px 34px; }

        .topbar {
            display: flex; justify-content: space-between;
            align-items: center; margin-bottom: 16px;
        }

        .btn {
            padding: 6px 12px; border-radius: 6px; border: none;
            cursor: pointer; font-size: 11px; font-weight: 500;
            text-decoration: none;
        }
        .btn-add { background: #fb923c; color: white; }

        .form-box {
            max-width: 420px; background: white; padding: 18px;
            border: 1px solid #e5e7eb; border-radius: 10px;
        }

        select, input[type=date] {
            width: 100%; padding: 8px; border-radius: 6px;
            border: 1px solid #e5e7eb; margin-bottom: 12px;
            font-size: 12px;
        }

        .checkbox-group {
            border: 1px solid #e5e7eb; border-radius: 8px;
            padding: 10px; max-height: 170px; overflow: auto;
            margin-bottom: 14px; font-size: 12px; background: #f9fafb;
        }

        .checkbox-group label { display: block; margin-bottom: 6px; }
        .disabled { color: #9ca3af; }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 14px;
            padding-bottom: 46px; /* biar status ga nutup teks */
            display: flex;
            flex-direction: column;
            gap: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,.06);
            position: relative;
        }

        .member { font-weight: 600; font-size: 14px; color: #7c2d12; }

        .books {
            background: #f8fafc; border: 1px dashed #e5e7eb;
            border-radius: 8px; padding: 8px 10px;
            font-size: 12px; color: #374151; line-height: 1.5;
        }

        .dates {
            display: flex; justify-content: space-between;
            font-size: 11px; color: #64748b;
        }

        .status {
            position: absolute;
            bottom: 12px;
            left: 14px;

            font-size: 10px;
            padding: 4px 10px;
            border-radius: 20px;
            font-weight: 600;
        }

        .status-ok { background: #dcfce7; color: #166534; }
        .status-overdue { background: #fee2e2; color: #991b1b; }

        .page-title{ font-size:18px; font-weight:600; }
    </style>
</head>

<body>

<div class="navbar">
    <div class="brand">Perpustakaan</div>
    <div class="menu">
        <a href="/buku"><i class="fa-solid fa-book"></i> Buku</a>
        <a href="/member"><i class="fa-solid fa-users"></i> Member</a>
        <a href="/peminjaman" class="active"><i class="fa-solid fa-clipboard-list"></i> Peminjaman</a>
        <a href="/"><i class="fa-solid fa-arrow-left"></i> Logout</a>
    </div>
</div>

<div class="container">


<?php if($mode == 'create'): ?>

<div class="form-box">
    <b>Tambah Peminjaman</b><br><br>

    <form action="/peminjaman" method="POST">
        <?php echo csrf_field(); ?>

        <label>Member</label>
        <select name="member_id" required>
            <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m->id); ?>"><?php echo e($m->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam" value="<?php echo e(date('Y-m-d')); ?>" required>

        <label>Pilih Buku</label>
        <div class="checkbox-group">
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="<?php echo e($b->stok == 0 ? 'disabled' : ''); ?>">
                    <input type="checkbox" name="buku_id[]" value="<?php echo e($b->id); ?>"
                        <?php echo e($b->stok == 0 ? 'disabled' : ''); ?>>
                    <?php echo e($b->judul); ?> (stok: <?php echo e($b->stok); ?>)
                    <?php if($b->stok == 0): ?>
                        <span style="color:red;font-size:11px;"> - habis</span>
                    <?php endif; ?>
                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button class="btn btn-add">Simpan</button>
        <a href="/peminjaman" class="btn">Batal</a>
    </form>
</div>

<?php endif; ?>



<?php if($mode == 'list'): ?>

<div class="topbar">
    <div class="page-title">Data Peminjaman</div>
    <a href="/peminjaman/create" class="btn btn-add">
        <i class="fa-solid fa-plus"></i> Tambah
    </a>
</div>

<div class="grid">

<?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
    $today = \Carbon\Carbon::today();
    $kembali = \Carbon\Carbon::parse($p->tanggal_kembali);
?>

<div class="card">
    <div class="member"><?php echo e($p->member->nama); ?></div>

    <div class="books">
        <?php $__currentLoopData = $p->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            • <?php echo e($d->buku->judul); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="dates">
        <div>Pinjam: <?php echo e($p->tanggal_pinjam); ?></div>
        <div>Kembali: <?php echo e($p->tanggal_kembali); ?></div>
    </div>

    <?php if($today->gt($kembali)): ?>
        <div class="status status-overdue">Overdue</div>
    <?php else: ?>
        <div class="status status-ok">Sedang Dipinjam</div>
    <?php endif; ?>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?>

</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\PeminjamanBukuPerpus\resources\views/peminjaman.blade.php ENDPATH**/ ?>