<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\BukuController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\PeminjamanController;
use App\Http\Controllers\KatalogController;

Route::get('/', fn() => redirect('/welcome'));

Route::view('/welcome', 'welcome_role');

// LOGIN PETUGAS (dari modal)
Route::post('/login', [LoginController::class,'login'])->name('login');
Route::post('/logout', [LoginController::class,'logout'])->name('logout');

// AREA PETUGAS (WAJIB LOGIN)
Route::middleware('auth')->group(function () {
    Route::resource('buku', BukuController::class);
    Route::resource('member', MemberController::class);
    Route::resource('peminjaman', PeminjamanController::class);
});

// KATALOG UMUM (ANGGOTA)
Route::get('/katalog', [KatalogController::class,'index']);

Route::put('/peminjaman/{id}/kembalikan', [PeminjamanController::class, 'kembalikan']);


