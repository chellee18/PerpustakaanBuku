<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;
use App\Services\StokStrategy;
use App\Services\StokAda;
use App\Services\StokHabis;


class BukuController extends Controller
{
    public function index()
    {
        $buku = Buku::all();

        foreach ($buku as $b) {

            /** @var StokStrategy $strategy */
            if ($b->stok > 0) {
                $strategy = new StokAda();
            } else {
                $strategy = new StokHabis();
            }

            // polymorphism dipakai di sini
            $b->status_stok = $strategy->tampilkan($b->stok);
        }

        return view('buku', [
            'buku' => $buku,
            'mode' => 'list'
        ]);
    }

    public function create()
    {
        return view('buku', [
            'mode' => 'create'
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required',
            'penulis' => 'required',
            'stok' => 'required|integer'
        ]);

        Buku::create([
            'judul' => $request->judul,
            'penulis' => $request->penulis,
            'stok' => $request->stok
        ]);

        return redirect('/buku');
    }
}
