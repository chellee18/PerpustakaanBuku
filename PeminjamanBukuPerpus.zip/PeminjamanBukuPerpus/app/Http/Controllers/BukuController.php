<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;
use App\Services\StokStrategy;
use App\Services\StokAda;
use App\Services\StokHabis;

class BukuController extends Controller
{
    public function index()
    {
        $buku = Buku::all();

        foreach ($buku as $b) {
            $strategy = $b->stok > 0 ? new StokAda() : new StokHabis();
            $b->status_stok = $strategy->tampilkan($b->stok);
        }

        return view('buku', ['buku'=>$buku,'mode'=>'list']);
    }

    public function create()
    {
        return view('buku',['mode'=>'create']);
    }

    public function store(Request $request)
    {
        $request->validate([
            'judul'=>'required','penulis'=>'required','stok'=>'required|integer'
        ]);

        Buku::create($request->only('judul','penulis','stok'));
        return redirect('/buku');
    }

    public function edit($id)
    {
        $buku = Buku::findOrFail($id);
        return view('buku',['mode'=>'edit','editBuku'=>$buku]);
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'judul'=>'required','penulis'=>'required','stok'=>'required|integer'
        ]);

        Buku::findOrFail($id)->update($request->only('judul','penulis','stok'));
        return redirect('/buku');
    }

    public function destroy($id)
    {
        Buku::destroy($id);
        return redirect('/buku');
    }
}
