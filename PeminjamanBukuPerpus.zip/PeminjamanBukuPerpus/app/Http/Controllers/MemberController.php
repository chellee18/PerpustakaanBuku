<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function index()
    {
        $member = Member::all();
        return view('member', [
            'member' => $member,
            'mode' => 'list'
        ]);
    }

    public function create()
    {
        return view('member', [
            'mode' => 'create'
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required'
        ]);

        Member::create($request->all());

        return redirect('/member');
    }

    public function edit($id)
    {
        $member = Member::findOrFail($id);

        return view('member', [
            'mode' => 'edit',
            'editMember' => $member
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required'
        ]);

        $member = Member::findOrFail($id);
        $member->update($request->all());

        return redirect('/member');
    }

    public function destroy($id)
    {
        Member::destroy($id);
        return redirect('/member');
    }
}
