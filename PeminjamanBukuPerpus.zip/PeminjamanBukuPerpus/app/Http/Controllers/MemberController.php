<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    // ===== TAMPIL LIST MEMBER =====
    public function index()
    {
        $member = Member::all();

        return view('member', [
            'member' => $member,
            'mode' => 'list'
        ]);
    }

    // ===== TAMPIL FORM TAMBAH =====
    public function create()
    {
        return view('member', [
            'mode' => 'create'
        ]);
    }

    // ===== SIMPAN DATA MEMBER =====
    public function store(Request $request)
    {
        $request->validate([
            'nama'   => 'required',
            'alamat' => 'required',
            'no_hp'  => 'required'
        ]);

        Member::create([
            'nama'   => $request->nama,
            'alamat' => $request->alamat,
            'no_hp'  => $request->no_hp
        ]);

        return redirect('/member');
    }
}
