<?php

namespace App\Http\Controllers;

use App\Models\Peminjaman;
use App\Models\DetailPeminjaman;
use App\Models\Member;
use App\Models\Buku;
use Illuminate\Http\Request;
use Carbon\Carbon;

class PeminjamanController extends Controller
{
    public function index()
    {
        $peminjaman = Peminjaman::with(['member', 'detail.buku'])->get();

        return view('peminjaman', [
            'mode' => 'list',
            'peminjaman' => $peminjaman
        ]);
    }

    public function create()
    {
        $member = Member::all();
        $buku = Buku::all();

        return view('peminjaman', [
            'mode' => 'create',
            'member' => $member,
            'buku' => $buku
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'member_id' => 'required',
            'buku_id' => 'required|array'
        ]);

        $peminjaman = Peminjaman::create([
            'member_id' => $request->member_id,
            'tanggal_pinjam' => Carbon::now(),
            'tanggal_kembali' => Carbon::now()->addDays(7)
        ]);

        foreach ($request->buku_id as $idBuku) {

            $buku = Buku::find($idBuku);

            if (!$buku || $buku->stok <= 0) {
                continue; // skip kalau stok habis
            }

            DetailPeminjaman::create([
                'peminjaman_id' => $peminjaman->id,
                'buku_id' => $idBuku
            ]);

            $buku->decrement('stok');
        }

        return redirect('/peminjaman');
    }

    public function destroy($id)
    {
        Peminjaman::destroy($id);
        return redirect('/peminjaman');
    }
}
