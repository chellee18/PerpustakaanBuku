<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class KatalogController extends Controller
{
    public function index(Request $request)
    {
        $query = Buku::query();

        if ($request->search) {
            $query->where('judul', 'like', '%' . $request->search . '%')
                  ->orWhere('penulis', 'like', '%' . $request->search . '%');
        }

        if ($request->filter == 'tersedia') {
            $query->where('stok', '>', 0);
        }

        $buku = $query->get();

        return view('katalog', compact('buku'));
    }
}
