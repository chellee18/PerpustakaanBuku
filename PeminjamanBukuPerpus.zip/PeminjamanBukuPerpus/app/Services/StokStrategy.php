<?php

namespace App\Services;

abstract class StokStrategy
{
    abstract public function tampilkan(int $stok): string;
}
