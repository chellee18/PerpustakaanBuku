<?php

namespace App\Services;

class StokAda extends StokStrategy
{
    public function tampilkan(int $stok): string
    {
        return (string) $stok; // tampilkan angka stok
    }
}
