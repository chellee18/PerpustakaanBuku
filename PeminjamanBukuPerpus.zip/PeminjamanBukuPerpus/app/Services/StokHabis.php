<?php

namespace App\Services;

class StokHabis extends StokStrategy
{
    public function tampilkan(int $stok): string
    {
        return "0"; // kalau habis tetap tampil 0
    }
}
