<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Peminjaman extends Model
{
    protected $table = 'peminjaman';
    
    public $timestamps = false;

    protected $fillable = [
        'member_id',
        'tanggal_pinjam',
        'tanggal_kembali',
        'status'
    ];

    public function member()
    {
        return $this->belongsTo(Member::class, 'member_id');
    }

    public function detail()
    {
        return $this->hasMany(DetailPeminjaman::class, 'peminjaman_id');
    }
}
